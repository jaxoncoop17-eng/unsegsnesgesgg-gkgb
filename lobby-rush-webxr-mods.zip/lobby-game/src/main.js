import * as THREE from 'three';
import { GLTFLoader } from 'three-addons/loaders/GLTFLoader.js';
import { mergeGeometries } from 'three-addons/utils/BufferGeometryUtils.js';
import { MeshBVH, acceleratedRaycast } from 'bvh';
import mapData from '../public/map.glb';

THREE.Mesh.prototype.raycast = acceleratedRaycast;

/* ------------------------------------------------------------------ config */
const CFG = {
  height: 3.2, radius: 0.7, eye: 2.8,
  walk: 13, sprint: 21, jump: 15, gravity: -48,
  cell: 1.5, region: { x0: -75, x1: 65, z0: -65, z1: 80 },
  stepMax: 1.45, startTime: 75, lives: 3,
};
const $ = (id) => document.getElementById(id);
const rand = (a, b) => a + Math.random() * (b - a);

/* ---------------------------------------------------------------- renderer */
const canvas = $('c');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.xr.enabled = true;
const MODS = { fly:false, speed:false, lowGravity:false, rainbow:false };
let spawnedProps = [];
let rainbowHue = 0;
let xrControllers = [];
for (let i = 0; i < 2; i++) { const c = renderer.xr.getController(i); c.userData.index = i; scene.add(c); xrControllers.push(c); }
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, 1, 0.12, 6000);
scene.add(camera);

const sky = new THREE.Mesh(
  new THREE.SphereGeometry(3000, 24, 16),
  new THREE.ShaderMaterial({
    side: THREE.BackSide, depthWrite: false, fog: false,
    uniforms: { top: { value: new THREE.Color(0x2f7fd8) }, mid: { value: new THREE.Color(0x9fd4ff) }, bot: { value: new THREE.Color(0xfff1d6) } },
    vertexShader: 'varying vec3 p;void main(){p=normalize(position);gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
    fragmentShader: 'uniform vec3 top,mid,bot;varying vec3 p;void main(){float h=p.y;vec3 c=h>0.?mix(mid,top,pow(h,.6)):mix(mid,bot,pow(-h,.5));gl_FragColor=vec4(c,1.);}',
  }));
sky.renderOrder = -10;
scene.add(sky);
scene.add(new THREE.HemisphereLight(0xcfe8ff, 0x7a6a50, 1.7));
const sun = new THREE.DirectionalLight(0xfff0d0, 1.9);
sun.position.set(80, 140, 50);
scene.add(sun);

function resize() {
  const w = window.innerWidth, h = window.innerHeight;
  renderer.setSize(w, h, false);
  camera.aspect = w / h; camera.updateProjectionMatrix();
}
window.addEventListener('resize', resize); resize();

/* -------------------------------------------------------------------- state */
const G = {
  ready: false, state: 'menu', // menu | playing | paused | over
  score: 0, wave: 1, time: CFG.startTime, lives: CFG.lives, best: 0,
  combo: 0, comboT: 0, invuln: 0, shake: 0,
  orbs: [], enemies: [], graph: null, collider: null, spawn: new THREE.Vector3(),
  testMode: /[?&]test\b/.test(location.search),
};
try { G.best = +localStorage.getItem('lobbyrush.best') || 0; } catch (e) { /* ignore */ }
$('best').textContent = G.best ? 'Best score: ' + G.best : '';

const P = {
  pos: new THREE.Vector3(), vel: new THREE.Vector3(), yaw: 0, pitch: 0,
  onGround: false, jumps: 0, stamina: 100, staminaDelay: 0, dashT: 0, dashCd: 0, dashDir: new THREE.Vector3(),
  coyote: 0, bob: 0,
};
const keys = {};

/* ------------------------------------------------------------------- audio */
let actx = null;
function beep(freq, dur = 0.12, type = 'sine', vol = 0.12, slide = 0) {
  try {
    actx = actx || new (window.AudioContext || window.webkitAudioContext)();
    const t = actx.currentTime, o = actx.createOscillator(), g = actx.createGain();
    o.type = type; o.frequency.setValueAtTime(freq, t);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, freq + slide), t + dur);
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(actx.destination); o.start(t); o.stop(t + dur + 0.02);
  } catch (e) { /* audio unavailable */ }
}
const sfx = {
  orb: (c) => { beep(620 + c * 90, 0.14, 'triangle', 0.14); setTimeout(() => beep(930 + c * 120, 0.16, 'triangle', 0.1), 60); },
  jump: () => beep(300, 0.14, 'square', 0.05, 260),
  djump: () => beep(450, 0.14, 'square', 0.05, 380),
  hurt: () => beep(180, 0.35, 'sawtooth', 0.16, -120),
  stomp: () => { beep(200, 0.18, 'square', 0.12, 300); setTimeout(() => beep(520, 0.15, 'triangle', 0.1), 80); },
  dash: () => beep(160, 0.2, 'sawtooth', 0.07, 500),
  wave: () => [523, 659, 784, 1046].forEach((f, i) => setTimeout(() => beep(f, 0.2, 'triangle', 0.13), i * 90)),
  over: () => [400, 320, 240, 160].forEach((f, i) => setTimeout(() => beep(f, 0.25, 'sawtooth', 0.12), i * 160)),
};

/* --------------------------------------------------------------- particles */
const PN = 600;
const pGeo = new THREE.BufferGeometry();
const pPos = new Float32Array(PN * 3), pCol = new Float32Array(PN * 3);
const pVel = new Float32Array(PN * 3), pLife = new Float32Array(PN);
pGeo.setAttribute('position', new THREE.BufferAttribute(pPos, 3));
pGeo.setAttribute('color', new THREE.BufferAttribute(pCol, 3));
const particles = new THREE.Points(pGeo, new THREE.PointsMaterial({
  size: 0.5, vertexColors: true, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, sizeAttenuation: true,
}));
particles.frustumCulled = false;
scene.add(particles);
for (let i = 0; i < PN; i++) pPos[i * 3 + 1] = -9999;
let pHead = 0;
function burst(pos, color, n = 40, speed = 8) {
  const c = new THREE.Color(color);
  for (let k = 0; k < n; k++) {
    const i = pHead++ % PN;
    pPos.set([pos.x, pos.y, pos.z], i * 3);
    const th = Math.random() * Math.PI * 2, ph = Math.acos(rand(-1, 1)), s = rand(0.3, 1) * speed;
    pVel.set([Math.sin(ph) * Math.cos(th) * s, Math.abs(Math.cos(ph)) * s + 2, Math.sin(ph) * Math.sin(th) * s], i * 3);
    pCol.set([c.r, c.g, c.b], i * 3);
    pLife[i] = rand(0.5, 1.1);
  }
}
function updateParticles(dt) {
  for (let i = 0; i < PN; i++) {
    if (pLife[i] <= 0) { pPos[i * 3 + 1] = -9999; continue; }
    pLife[i] -= dt;
    pVel[i * 3 + 1] -= 18 * dt;
    pPos[i * 3] += pVel[i * 3] * dt; pPos[i * 3 + 1] += pVel[i * 3 + 1] * dt; pPos[i * 3 + 2] += pVel[i * 3 + 2] * dt;
  }
  pGeo.attributes.position.needsUpdate = true; pGeo.attributes.color.needsUpdate = true;
}

/* -------------------------------------------------------------- map loading */
function loadMap(onProgress) {
  return new Promise((resolve, reject) => {
    const buf = mapData.buffer.slice(mapData.byteOffset, mapData.byteOffset + mapData.byteLength);
    onProgress(0.15);
    new GLTFLoader().parse(buf, '', (gltf) => resolve(gltf), reject);
  });
}

function prepareMap(gltf) {
  const root = gltf.scene;
  scene.add(root);
  root.updateMatrixWorld(true);
  const lobby = new THREE.Box2(new THREE.Vector2(-85, -75), new THREE.Vector2(75, 90));
  const geoms = [];
  const bb = new THREE.Box3();
  root.traverse((o) => {
    if (!o.isMesh) return;
    const mats = [].concat(o.material);
    for (const m of mats) { m.metalness = 0; m.roughness = 1; if (m.map) m.map.anisotropy = 4; }
    const foliage = mats.some((m) => m.transparent || m.alphaTest > 0);
    o.geometry.computeBoundingBox();
    bb.copy(o.geometry.boundingBox).applyMatrix4(o.matrixWorld);
    const size = bb.getSize(new THREE.Vector3());
    const inLobby = bb.max.x > lobby.min.x && bb.min.x < lobby.max.x && bb.max.z > lobby.min.y && bb.min.z < lobby.max.y;
    if (!inLobby || foliage || size.x > 220 || size.z > 220 || size.y > 400 || bb.min.y > 120) return;
    const g = new THREE.BufferGeometry();
    const src = o.geometry.index ? o.geometry.toNonIndexed() : o.geometry.clone();
    g.setAttribute('position', src.attributes.position.clone());
    g.applyMatrix4(o.matrixWorld);
    geoms.push(g);
  });
  const merged = mergeGeometries(geoms, false);
  const index = new Uint32Array(merged.attributes.position.count);
  for (let i = 0; i < index.length; i++) index[i] = i;
  merged.setIndex(new THREE.BufferAttribute(index, 1));
  merged.boundsTree = new MeshBVH(merged, { maxLeafTris: 4 });
  const collider = new THREE.Mesh(merged, new THREE.MeshBasicMaterial({ side: THREE.DoubleSide }));
  collider.updateMatrixWorld(true);
  G.collider = collider;
}

/* ------------------------------------------------------- walkable graph/AI */
function buildGraph() {
  const { x0, x1, z0, z1 } = CFG.region, c = CFG.cell;
  const nx = Math.floor((x1 - x0) / c), nz = Math.floor((z1 - z0) / c);
  const rc = new THREE.Raycaster(); rc.near = 0; rc.far = 600;
  const down = new THREE.Vector3(0, -1, 0), o = new THREE.Vector3();
  const cells = new Array(nx * nz);
  let total = 0;
  for (let iz = 0; iz < nz; iz++) {
    for (let ix = 0; ix < nx; ix++) {
      o.set(x0 + (ix + 0.5) * c, 300, z0 + (iz + 0.5) * c);
      rc.set(o, down);
      const hits = rc.intersectObject(G.collider, false);
      const layers = [];
      for (let h = 0; h < hits.length; h++) {
        const hit = hits[h];
        if (hit.face.normal.y < 0.72) continue;
        const above = h > 0 ? hits[h - 1].point.y : Infinity;
        if (above - hit.point.y < CFG.height + 0.4) continue;
        if (layers.length && Math.abs(layers[layers.length - 1].y - hit.point.y) < 0.3) continue;
        layers.push({ y: hit.point.y, id: -1, comp: -1 });
      }
      cells[iz * nx + ix] = layers;
      total += layers.length;
    }
  }
  // nodes + adjacency
  const nodes = [];
  for (let iz = 0; iz < nz; iz++) for (let ix = 0; ix < nx; ix++) {
    for (const L of cells[iz * nx + ix]) {
      L.id = nodes.length;
      nodes.push({ x: x0 + (ix + 0.5) * c, y: L.y, z: z0 + (iz + 0.5) * c, ix, iz, nb: [] });
    }
  }
  // obstruction helpers: nodes touching walls/props are unusable, edges must be free of obstacles
  const ro = new THREE.Vector3(), rd = new THREE.Vector3();
  const clear = (ax, ay, az, bx, by, bz) => {
    rd.set(bx - ax, by - ay, bz - az); const len = rd.length(); if (len < 1e-4) return true; rd.multiplyScalar(1 / len);
    rc.firstHitOnly = true; rc.near = 0; rc.far = len; rc.set(ro.set(ax, ay, az), rd);
    return rc.intersectObject(G.collider, false).length === 0;
  };
  const HS = [0.9, 2.3];
  for (const n of nodes) {
    n.blocked = false;
    for (const h of HS) for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1], [0.7, 0.7], [-0.7, 0.7], [0.7, -0.7], [-0.7, -0.7]]) {
      if (!clear(n.x, n.y + h, n.z, n.x + dx * 0.75, n.y + h, n.z + dz * 0.75)) { n.blocked = true; break; }
    }
    if (!n.blocked && !clear(n.x, n.y + 0.4, n.z, n.x, n.y + CFG.height + 0.2, n.z)) n.blocked = true;
  }
  for (let iz = 0; iz < nz; iz++) for (let ix = 0; ix < nx; ix++) {
    for (const L of cells[iz * nx + ix]) {
      const A = nodes[L.id]; if (A.blocked) continue;
      for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
        if (!dx && !dz) continue;
        const jx = ix + dx, jz = iz + dz;
        if (jx < 0 || jz < 0 || jx >= nx || jz >= nz) continue;
        let best = null, bd = Infinity;
        for (const M of cells[jz * nx + jx]) {
          const d = Math.abs(M.y - L.y);
          if (d <= CFG.stepMax * (dx && dz ? 1.4 : 1) && d < bd && !nodes[M.id].blocked) { bd = d; best = M; }
        }
        if (!best) continue;
        const B = nodes[best.id];
        if (clear(A.x, A.y + HS[0], A.z, B.x, B.y + HS[0], B.z) && clear(A.x, A.y + HS[1], A.z, B.x, B.y + HS[1], B.z)) A.nb.push(best.id);
      }
    }
  }
  // drop nodes with fewer than 3 neighbours on the rim (cliff edges) from spawn use
  for (const n of nodes) n.edge = n.nb.length < 8;
  // components
  const comp = new Int32Array(nodes.length).fill(-1); const sizes = [];
  for (let s = 0; s < nodes.length; s++) {
    if (comp[s] >= 0) continue;
    const id = sizes.length; let cnt = 0; const q = [s]; comp[s] = id;
    while (q.length) { const u = q.pop(); cnt++; for (const v of nodes[u].nb) if (comp[v] < 0) { comp[v] = id; q.push(v); } }
    sizes.push(cnt);
  }
  let main = 0; sizes.forEach((s, i) => { if (s > sizes[main]) main = i; });
  const playable = []; nodes.forEach((n, i) => { n.main = comp[i] === main; if (n.main) playable.push(i); });
  // grid for nearest-node lookup (highest layer under a given y)
  G.graph = { nodes, cells, nx, nz, playable, dist: new Int32Array(nodes.length), nearest(x, y, z) {
    const ix = Math.floor((x - x0) / c), iz = Math.floor((z - z0) / c);
    let best = -1, bd = Infinity;
    for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
      const jx = ix + dx, jz = iz + dz;
      if (jx < 0 || jz < 0 || jx >= nx || jz >= nz) continue;
      for (const L of cells[jz * nx + jx]) {
        if (!nodes[L.id].main) continue;
        const d = Math.hypot(nodes[L.id].x - x, nodes[L.id].z - z) + Math.abs(L.y - (y - 1)) * 2.5;
        if (d < bd) { bd = d; best = L.id; }
      }
    }
    return best;
  } };
  // spawn: playable, non-edge node nearest the centroid of the main component
  let cx = 0, cz = 0; playable.forEach((i) => { cx += nodes[i].x; cz += nodes[i].z; });
  cx /= playable.length; cz /= playable.length;
  let sb = playable[0], sd = Infinity;
  for (const i of playable) { const n = nodes[i]; if (n.edge) continue; const d = Math.hypot(n.x - cx, n.z - cz); if (d < sd) { sd = d; sb = i; } }
  G.spawn.set(nodes[sb].x, nodes[sb].y + CFG.radius + 0.05, nodes[sb].z);
  G.graph.spawnNode = sb;
  buildMinimapBase();
}

function bfsFrom(src) {
  const gph = G.graph, dist = gph.dist; dist.fill(-1);
  if (src < 0) return;
  const q = [src]; dist[src] = 0;
  for (let h = 0; h < q.length; h++) { const u = q[h]; for (const v of gph.nodes[u].nb) if (dist[v] < 0 && gph.nodes[v].main) { dist[v] = dist[u] + 1; q.push(v); } }
}

/* ---------------------------------------------------------------- minimap */
const mini = $('minic'), mctx = mini.getContext('2d');
const mbase = document.createElement('canvas'); mbase.width = mbase.height = 380;
let mscale = 1, mcx = 0, mcz = 0;
function buildMinimapBase() {
  const nodes = G.graph.nodes; let minY = Infinity, maxY = -Infinity, r = 0, sx = 0, sz = 0, cnt = 0;
  for (const i of G.graph.playable) { const n = nodes[i]; sx += n.x; sz += n.z; cnt++; minY = Math.min(minY, n.y); maxY = Math.max(maxY, n.y); }
  mcx = sx / cnt; mcz = sz / cnt;
  for (const i of G.graph.playable) r = Math.max(r, Math.hypot(nodes[i].x - mcx, nodes[i].z - mcz));
  mscale = 180 / (r + 4);
  const b = mbase.getContext('2d'); b.clearRect(0, 0, 380, 380);
  for (const i of G.graph.playable) {
    const n = nodes[i], t = (n.y - minY) / Math.max(1, maxY - minY);
    b.fillStyle = `rgb(${Math.round(70 + t * 170)},${Math.round(150 + t * 80)},${Math.round(80 + t * 140)})`;
    b.fillRect(190 + (n.x - mcx) * mscale - 1.5, 190 + (n.z - mcz) * mscale - 1.5, CFG.cell * mscale + 1.5, CFG.cell * mscale + 1.5);
  }
}
function drawMinimap() {
  mctx.clearRect(0, 0, 380, 380);
  mctx.save(); mctx.translate(190, 190); mctx.rotate(P.yaw); mctx.translate(-190, -190);
  // rotate so that "up" is where the player faces: base is north-up (−z), yaw rotates world
  const ox = 190 - (P.pos.x - mcx) * mscale, oz = 190 - (P.pos.z - mcz) * mscale;
  mctx.globalAlpha = 0.9; mctx.drawImage(mbase, ox - 190 + 0, oz - 190 + 0);
  mctx.globalAlpha = 1;
  const pt = (x, z) => [190 + (x - P.pos.x) * mscale, 190 + (z - P.pos.z) * mscale];
  for (const orb of G.orbs) { const [x, y] = pt(orb.pos.x, orb.pos.z); mctx.fillStyle = '#ffd54a'; mctx.beginPath(); mctx.arc(x, y, 7, 0, 7); mctx.fill(); mctx.strokeStyle = '#000a'; mctx.lineWidth = 2; mctx.stroke(); }
  for (const e of G.enemies) { if (e.dead) continue; const [x, y] = pt(e.pos.x, e.pos.z); mctx.fillStyle = '#ff4d4d'; mctx.beginPath(); mctx.arc(x, y, 7, 0, 7); mctx.fill(); mctx.strokeStyle = '#fff'; mctx.lineWidth = 2; mctx.stroke(); }
  mctx.restore();
  mctx.fillStyle = '#fff'; mctx.beginPath(); mctx.moveTo(190, 172); mctx.lineTo(200, 202); mctx.lineTo(190, 196); mctx.lineTo(180, 202); mctx.closePath(); mctx.fill();
  mctx.strokeStyle = '#000a'; mctx.lineWidth = 2; mctx.stroke();
}

/* ------------------------------------------------------------------ entities */
const orbGeo = new THREE.IcosahedronGeometry(0.75, 1);
const orbMat = new THREE.MeshBasicMaterial({ color: 0xffd54a });
const ringGeo = new THREE.TorusGeometry(1.15, 0.07, 8, 32);
const ringMat = new THREE.MeshBasicMaterial({ color: 0xfff3b0 });
const beamGeo = new THREE.CylinderGeometry(0.22, 0.22, 26, 10, 1, true); beamGeo.translate(0, 13, 0);
const beamMat = new THREE.MeshBasicMaterial({ color: 0xffe066, transparent: true, opacity: 0.3, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide });
function makeOrb(node) {
  const g = new THREE.Group();
  const core = new THREE.Mesh(orbGeo, orbMat);
  const ring = new THREE.Mesh(ringGeo, ringMat);
  const beam = new THREE.Mesh(beamGeo, beamMat); beam.position.y = -1.6; beam.frustumCulled = false;
  g.add(core, ring, beam);
  g.position.set(node.x, node.y + 2.1, node.z);
  scene.add(g);
  return { obj: g, core, ring, pos: g.position, phase: Math.random() * 6 };
}

const bodyGeo = new THREE.SphereGeometry(1.2, 20, 16);
const spikeGeo = new THREE.ConeGeometry(0.28, 0.7, 6);
const eyeGeo = new THREE.SphereGeometry(0.34, 12, 10), pupGeo = new THREE.SphereGeometry(0.16, 10, 8);
const bodyMat = new THREE.MeshLambertMaterial({ color: 0xd8344a, emissive: 0x3a0610 });
const spikeMat = new THREE.MeshLambertMaterial({ color: 0x6b1230 });
const eyeMat = new THREE.MeshBasicMaterial({ color: 0xffffff }), pupMat = new THREE.MeshBasicMaterial({ color: 0x111111 });
function makeEnemy(nodeIdx) {
  const n = G.graph.nodes[nodeIdx];
  const g = new THREE.Group(), body = new THREE.Group();
  body.add(new THREE.Mesh(bodyGeo, bodyMat));
  for (let i = 0; i < 14; i++) {
    const s = new THREE.Mesh(spikeGeo, spikeMat), d = new THREE.Vector3(rand(-1, 1), rand(-0.2, 1), rand(-1, 1)).normalize();
    s.position.copy(d).multiplyScalar(1.25); s.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), d); body.add(s);
  }
  for (const sx of [-0.45, 0.45]) {
    const e = new THREE.Mesh(eyeGeo, eyeMat), p = new THREE.Mesh(pupGeo, pupMat);
    e.position.set(sx, 0.35, 1.0); p.position.set(sx, 0.35, 1.25); body.add(e, p);
  }
  g.add(body); scene.add(g);
  return {
    obj: g, body, pos: g.position, node: nodeIdx, target: nodeIdx, dead: false, respawn: 0, phase: Math.random() * 6,
    speed: 0, sleep: 2.2, flat: 0, init() { g.position.set(n.x, n.y + 1.25, n.z); return this; },
  }.init();
}

function clearEntities() {
  for (const o of G.orbs) scene.remove(o.obj);
  for (const e of G.enemies) scene.remove(e.obj);
  G.orbs = []; G.enemies = [];
}

function farNode(from, minD) {
  const nodes = G.graph.nodes, pl = G.graph.playable;
  for (let t = 0; t < 200; t++) {
    const i = pl[(Math.random() * pl.length) | 0], n = nodes[i];
    if (n.edge) continue;
    if (Math.hypot(n.x - from.x, n.z - from.z) >= minD) return i;
  }
  return pl[(Math.random() * pl.length) | 0];
}

function spawnWave() {
  clearEntities();
  const nOrbs = Math.min(8 + G.wave * 2, 24), nEn = Math.min(1 + G.wave, 8);
  const used = [];
  let guard = 0;
  while (G.orbs.length < nOrbs && guard++ < 800) {
    const i = farNode(P.pos, 12), n = G.graph.nodes[i];
    if (used.some((u) => Math.hypot(u.x - n.x, u.z - n.z) < 9)) continue;
    used.push(n); G.orbs.push(makeOrb(n));
  }
  for (let k = 0; k < nEn; k++) {
    const e = makeEnemy(farNode(P.pos, 28)); e.speed = Math.min(4.5 + G.wave * 0.7, 9.5); G.enemies.push(e);
  }
  updateHUD();
}

/* -------------------------------------------------------------- player/phys */
const tmpBox = new THREE.Box3(), tmpSeg = new THREE.Line3(), tv1 = new THREE.Vector3(), tv2 = new THREE.Vector3();
const segLen = CFG.height - CFG.radius * 2;
function collide() {
  const bvh = G.collider.geometry.boundsTree;
  tmpSeg.start.copy(P.pos); tmpSeg.end.copy(P.pos); tmpSeg.end.y += segLen;
  tmpBox.makeEmpty(); tmpBox.expandByPoint(tmpSeg.start); tmpBox.expandByPoint(tmpSeg.end);
  tmpBox.min.addScalar(-CFG.radius); tmpBox.max.addScalar(CFG.radius);
  bvh.shapecast({
    intersectsBounds: (box) => box.intersectsBox(tmpBox),
    intersectsTriangle: (tri) => {
      const d = tri.closestPointToSegment(tmpSeg, tv1, tv2);
      if (d < CFG.radius) {
        const depth = CFG.radius - d, dir = tv2.sub(tv1).normalize();
        tmpSeg.start.addScaledVector(dir, depth); tmpSeg.end.addScaledVector(dir, depth);
      }
    },
  });
  return tv2.subVectors(tmpSeg.start, P.pos).clone();
}

const fwd = new THREE.Vector3(), rgt = new THREE.Vector3(), wish = new THREE.Vector3();
function stepPlayer(dt) {
  // input
  let mx = 0, mz = 0;
  if (keys.KeyW) mz -= 1; if (keys.KeyS) mz += 1; if (keys.KeyA) mx -= 1; if (keys.KeyD) mx += 1;
  wish.set(mx, 0, mz); if (wish.lengthSq() > 0) wish.normalize();
  const sy = Math.sin(P.yaw), cy = Math.cos(P.yaw);
  const wx = wish.x * cy + wish.z * sy, wz = -wish.x * sy + wish.z * cy;
  const moving = wish.lengthSq() > 0;
  const wantSprint = (keys.ShiftLeft || keys.ShiftRight) && moving && P.stamina > 2 && P.staminaDelay <= 0;
  if (wantSprint) { P.stamina = Math.max(0, P.stamina - 32 * dt); if (P.stamina <= 0) P.staminaDelay = 1.2; }
  else { P.staminaDelay = Math.max(0, P.staminaDelay - dt); if (P.staminaDelay <= 0) P.stamina = Math.min(100, P.stamina + 22 * dt); }
  const speed = (wantSprint ? CFG.sprint : CFG.walk) * (MODS.speed ? 2.2 : 1);
  if (MODS.fly) { if (keys.Space) P.vel.y = 13; else if (keys.ControlLeft || keys.ControlRight) P.vel.y = -13; else P.vel.y *= 0.8; } 
  const accel = P.onGround ? 14 : 4.5;
  const k = 1 - Math.exp(-accel * dt);
  P.vel.x += (wx * speed - P.vel.x) * k;
  P.vel.z += (wz * speed - P.vel.z) * k;

  // dash
  P.dashCd = Math.max(0, P.dashCd - dt);
  if (P.dashT > 0) { P.dashT -= dt; P.vel.x = P.dashDir.x * 42; P.vel.z = P.dashDir.z * 42; P.vel.y = Math.max(P.vel.y, 0); }

  // gravity
  if (!MODS.fly) P.vel.y += CFG.gravity * (MODS.lowGravity ? 0.28 : 1) * dt;
  if (P.vel.y < -70) P.vel.y = -70;
  P.coyote = P.onGround ? 0.12 : Math.max(0, P.coyote - dt);

  const subs = 4, h = dt / subs;
  let grounded = false;
  for (let s = 0; s < subs; s++) {
    P.pos.addScaledVector(P.vel, h);
    const push = collide();
    const g = push.y > Math.abs(h * P.vel.y * 0.25);
    const off = Math.max(0, push.length() - 1e-5);
    if (off > 0) {
      push.normalize(); P.pos.addScaledVector(push, off);
      if (!g) { P.vel.addScaledVector(push, -push.dot(P.vel)); }
      else { if (P.vel.y < 0) P.vel.y = 0; }
    }
    if (g) grounded = true;
  }
  P.onGround = grounded;
  if (grounded) P.jumps = 0;
  if (moving && grounded) P.bob += dt * speed * 0.65;
}

function tryJump() {
  if (G.state !== 'playing') return;
  if (P.onGround || P.coyote > 0) { P.vel.y = CFG.jump; P.onGround = false; P.coyote = 0; P.jumps = 1; sfx.jump(); }
  else if (P.jumps < 2) { P.vel.y = CFG.jump * 0.95; P.jumps = 2; sfx.djump(); burst(tv1.copy(P.pos), 0x9fe8ff, 14, 4); }
}
function tryDash() {
  if (G.state !== 'playing' || P.dashCd > 0) return;
  let mx = 0, mz = 0;
  if (keys.KeyW) mz -= 1; if (keys.KeyS) mz += 1; if (keys.KeyA) mx -= 1; if (keys.KeyD) mx += 1;
  if (!mx && !mz) mz = -1;
  const l = Math.hypot(mx, mz); mx /= l; mz /= l;
  const sy = Math.sin(P.yaw), cy = Math.cos(P.yaw);
  P.dashDir.set(mx * cy + mz * sy, 0, -mx * sy + mz * cy);
  P.dashT = 0.17; P.dashCd = 2.4; sfx.dash();
  burst(tv1.copy(P.pos).setY(P.pos.y + 1), 0xffb347, 18, 5);
}

/* ------------------------------------------------------------ game logic */
let msgTimer = 0;
function say(text, secs = 1.6) { const m = $('msg'); m.textContent = text; m.classList.add('show'); msgTimer = secs; }
function updateHUD() {
  $('score').textContent = G.score;
  $('time').textContent = Math.max(0, Math.ceil(G.time));
  $('time').classList.toggle('low', G.time <= 10);
  $('wave').textContent = G.wave;
  $('orbs').textContent = G.orbs.length;
  $('lives').textContent = '❤'.repeat(Math.max(0, G.lives)) + '♡'.repeat(Math.max(0, CFG.lives - G.lives));
  $('combo').textContent = G.combo > 1 ? 'COMBO x' + Math.min(G.combo, 5) : '';
}

function respawnPlayer() {
  P.pos.copy(G.spawn); P.vel.set(0, 0, 0); P.dashT = 0; P.onGround = false;
}

function resetGame() {
  G.score = 0; G.wave = 1; G.time = CFG.startTime; G.lives = CFG.lives; G.combo = 0; G.comboT = 0; G.invuln = 0;
  P.stamina = 100; P.dashCd = 0; P.yaw = 0; P.pitch = 0;
  respawnPlayer(); spawnWave();
  say('WAVE 1', 1.6);
}

function hurt(from) {
  if (G.invuln > 0) return;
  G.lives--; G.invuln = 1.8; G.combo = 0; G.shake = 0.5; sfx.hurt();
  const f = $('flash'); f.style.opacity = 1; setTimeout(() => (f.style.opacity = 0), 220);
  if (from) { tv1.subVectors(P.pos, from).setY(0).normalize(); P.vel.x = tv1.x * 22; P.vel.z = tv1.z * 22; P.vel.y = 12; P.onGround = false; }
  if (G.lives <= 0) gameOver('Out of lives!');
}

function gameOver(reason) {
  G.state = 'over'; sfx.over();
  if (G.score > G.best) { G.best = G.score; try { localStorage.setItem('lobbyrush.best', G.best); } catch (e) { /* ignore */ } }
  document.exitPointerLock && document.exitPointerLock();
  const ov = $('overlay'); ov.classList.remove('hidden');
  ov.querySelector('.card').innerHTML = `<h1>GAME OVER</h1><p>${reason}</p><p style="font-size:30px;font-weight:900">Score ${G.score}</p><p>Reached wave ${G.wave}</p><div id="best">Best score: ${G.best}</div><button id="play">Play again</button>`;
  $('play').onclick = startGame;
}

function startGame() {
  if (!G.ready) return;
  $('overlay').classList.add('hidden');
  resetGame(); G.state = 'playing';
  if (!G.testMode) canvas.requestPointerLock && canvas.requestPointerLock();
  beep(440, 0.1, 'triangle', 0.08);
}

const mp = new THREE.Vector3();
function stepGame(dt) {
  if (G.state !== 'playing') return;
  G.time -= dt; G.invuln = Math.max(0, G.invuln - dt); G.shake = Math.max(0, G.shake - dt);
  if (G.comboT > 0) { G.comboT -= dt; if (G.comboT <= 0) G.combo = 0; }
  if (G.time <= 0) { G.time = 0; updateHUD(); return gameOver("Time's up!"); }
  stepPlayer(dt);
  if (P.pos.y < G.spawn.y - 60) { G.time = Math.max(1, G.time - 5); G.combo = 0; respawnPlayer(); say('-5s  Fell off!', 1.2); sfx.hurt(); }

  // orbs
  const eye = tv1.set(P.pos.x, P.pos.y + CFG.height * 0.5, P.pos.z);
  for (let i = G.orbs.length - 1; i >= 0; i--) {
    const o = G.orbs[i]; o.phase += dt;
    o.core.rotation.y += dt * 2.5; o.core.position.y = Math.sin(o.phase * 2.5) * 0.3;
    o.ring.rotation.x = o.phase * 1.6; o.ring.rotation.y = o.phase * 1.1; o.ring.position.y = o.core.position.y;
    if (o.pos.distanceTo(eye) < 2.6) {
      G.combo = G.comboT > 0 ? G.combo + 1 : 1; G.comboT = 3.2;
      const mult = Math.min(G.combo, 5);
      G.score += 100 * mult; G.time += 1.5;
      sfx.orb(mult); burst(o.pos, 0xffd54a, 36, 9);
      scene.remove(o.obj); G.orbs.splice(i, 1);
      if (mult > 1) say('x' + mult, 0.6);
    }
  }
  if (!G.orbs.length) {
    G.score += 500 + Math.round(G.time) * 5; G.time += 10; G.wave++;
    sfx.wave(); spawnWave(); say('WAVE ' + G.wave + '!', 2);
    G.invuln = Math.max(G.invuln, 1.2);
  }

  // enemies (follow the walkable graph toward the player)
  G.enemyTick = (G.enemyTick || 0) - dt;
  const pn = G.graph.nearest(P.pos.x, P.pos.y, P.pos.z);
  if (G.enemyTick <= 0 && pn >= 0) { bfsFrom(pn); G.enemyTick = 0.25; }
  const dist = G.graph.dist, nodes = G.graph.nodes;
  for (const e of G.enemies) {
    if (e.dead) { e.respawn -= dt; if (e.respawn <= 0) { e.dead = false; e.node = e.target = farNode(P.pos, 30); const n = nodes[e.node]; e.pos.set(n.x, n.y + 1.25, n.z); e.obj.visible = true; e.sleep = 1.5; } continue; }
    e.phase += dt; e.sleep -= dt; e.flat = Math.max(0, e.flat - dt * 3);
    if (e.sleep <= 0) {
      const tn = nodes[e.target];
      mp.set(tn.x, tn.y + 1.25, tn.z).sub(e.pos);
      const d = mp.length();
      if (d < 0.4) {
        let best = e.target, bd = dist[e.target] < 0 ? 1e9 : dist[e.target];
        for (const v of tn.nb) if (dist[v] >= 0 && dist[v] < bd) { bd = dist[v]; best = v; }
        if (best === e.target && dist[e.target] < 0) { const nb = tn.nb[(Math.random() * tn.nb.length) | 0]; if (nb !== undefined) best = nb; }
        e.node = e.target; e.target = best;
      } else { mp.multiplyScalar(1 / d); e.pos.addScaledVector(mp, Math.min(d, e.speed * dt)); e.obj.rotation.y = Math.atan2(mp.x, mp.z); }
    }
    e.body.position.y = Math.abs(Math.sin(e.phase * 5)) * 0.35;
    const sq = 1 - e.flat * 0.5; e.body.scale.set(1 + e.flat * 0.4, sq, 1 + e.flat * 0.4);

    // contact
    const dx = P.pos.x - e.pos.x, dz = P.pos.z - e.pos.z, hd = Math.hypot(dx, dz);
    const feet = P.pos.y - CFG.radius, top = e.pos.y + 1.0;
    if (hd < 1.9 && P.pos.y + CFG.height > e.pos.y - 1 && feet < top + 0.5) {
      if (feet > e.pos.y + 0.2 && P.vel.y < 1) {
        e.dead = true; e.respawn = 4.5; e.obj.visible = false; P.vel.y = 17; P.jumps = 1;
        G.score += 150; G.time += 2; sfx.stomp(); burst(e.pos, 0xff5577, 40, 10); say('STOMP! +150', 0.8);
      } else hurt(e.pos);
    }
  }

  // orb compass
  let near = null, nd = Infinity;
  for (const o of G.orbs) { const d = Math.hypot(o.pos.x - P.pos.x, o.pos.z - P.pos.z); if (d < nd) { nd = d; near = o; } }
  if (near) {
    const fx = -Math.sin(P.yaw), fz = -Math.cos(P.yaw);
    const rel = Math.atan2(near.pos.z - P.pos.z, near.pos.x - P.pos.x) - Math.atan2(fz, fx);
    $('arrowhead').style.transform = `rotate(${rel.toFixed(3)}rad)`;
    $('dist').textContent = Math.round(nd) + 'm';
  }
  $('stam').style.width = P.stamina + '%';
  $('dash').style.width = (100 - (P.dashCd / 2.4) * 100) + '%';
  updateHUD();
}

/* ------------------------------------------------------------------- loop */
const clock = new THREE.Clock();
function frame() {
  const dt = Math.min(clock.getDelta(), 0.05);
  if (G.ready) {
    stepGame(dt);
    updateParticles(dt);
    if (msgTimer > 0) { msgTimer -= dt; if (msgTimer <= 0) $('msg').classList.remove('show'); }
    const shake = G.shake * 0.25;
    const bob = P.onGround ? Math.sin(P.bob) * 0.06 : 0;
    camera.position.set(P.pos.x + rand(-shake, shake), P.pos.y + CFG.eye - CFG.radius + bob + rand(-shake, shake), P.pos.z);
    camera.rotation.set(P.pitch, P.yaw, 0, 'YXZ');
    const sprinting = (keys.ShiftLeft || keys.ShiftRight) && P.stamina > 2;
    const fov = 75 + (P.dashT > 0 ? 18 : sprinting ? 8 : 0);
    camera.fov += (fov - camera.fov) * Math.min(1, dt * 8); camera.updateProjectionMatrix();
    sky.position.copy(camera.position);
    if (G.state === 'playing') drawMinimap();
    if (G.invuln > 0 && G.state === 'playing') $('cross').style.opacity = Math.floor(G.invuln * 10) % 2 ? 0.2 : 1; else $('cross').style.opacity = 1;
  }
  if (MODS.rainbow) { rainbowHue = (rainbowHue + 0.0015) % 1; sun.color.setHSL(rainbowHue, 0.9, 0.65); }
  if (renderer.xr.isPresenting) {
    const session = renderer.xr.getSession();
    for (const source of (session?.inputSources || [])) { const gp = source.gamepad; if (!gp) continue; const ax = gp.axes || []; if (ax.length >= 4) { keys.KeyW = ax[3] < -0.25; keys.KeyS = ax[3] > 0.25; keys.KeyA = ax[2] < -0.25; keys.KeyD = ax[2] > 0.25; } if (gp.buttons?.[0]?.pressed) tryJump(); if (gp.buttons?.[1]?.pressed) tryDash(); }
  }
  renderer.render(scene, camera);
}

/* ------------------------------------------------------------------ input */
window.addEventListener('keydown', (e) => {
  if (e.repeat) return;
  keys[e.code] = true;
  if (e.code === 'Space') { e.preventDefault(); tryJump(); }
  if (e.code === 'KeyE') tryDash();
  if (e.code === 'KeyM') $('mods').classList.toggle('hidden');
});
window.addEventListener('keyup', (e) => { keys[e.code] = false; });
function look(dx, dy) {
  P.yaw -= dx * 0.0022; P.pitch = Math.max(-1.45, Math.min(1.45, P.pitch - dy * 0.0022));
}
let dragging = false;
document.addEventListener('mousemove', (e) => {
  if (G.state !== 'playing') return;
  if (document.pointerLockElement === canvas) look(e.movementX, e.movementY);
  else if (dragging) look(e.movementX, e.movementY);
});
canvas.addEventListener('mousedown', () => {
  if (G.state === 'playing' || G.state === 'paused') {
    if (canvas.requestPointerLock) { try { const r = canvas.requestPointerLock(); if (r && r.catch) r.catch(() => {}); } catch (e) { /* ignore */ } }
    dragging = true;
  }
});
window.addEventListener('mouseup', () => { dragging = false; });
document.addEventListener('pointerlockchange', () => {
  if (document.pointerLockElement === canvas) {
    if (G.state === 'paused') { G.state = 'playing'; $('overlay').classList.add('hidden'); }
  } else if (G.state === 'playing' && !G.testMode && !dragging) {
    G.state = 'paused'; for (const k in keys) keys[k] = false;
    $('overlay').classList.remove('hidden');
    $('overlay').querySelector('.card').innerHTML = '<h1>PAUSED</h1><p>Click to get back in the game.</p><button id="resume">Resume</button>';
    $('resume').onclick = () => { canvas.requestPointerLock(); G.state = 'playing'; $('overlay').classList.add('hidden'); };
  }
});
window.addEventListener('blur', () => { for (const k in keys) keys[k] = false; });
setInterval(() => {
  // arrow keys also turn the camera (works without pointer lock)
  if (G.state !== 'playing') return;
  if (keys.ArrowLeft) look(-8, 0); if (keys.ArrowRight) look(8, 0);
  if (keys.ArrowUp) look(0, -6); if (keys.ArrowDown) look(0, 6);
}, 16);

/* -------------------------------------------------------------------- boot */
async function boot() {
  const bar = $('loadbar'), btn = $('play');
  try {
    bar.style.width = '10%';
    await new Promise((r) => setTimeout(r, 30));
    const gltf = await loadMap((p) => (bar.style.width = p * 100 + '%'));
    bar.style.width = '60%'; await new Promise((r) => setTimeout(r, 20));
    prepareMap(gltf);
    bar.style.width = '80%'; await new Promise((r) => setTimeout(r, 20));
    buildGraph();
    bar.style.width = '100%';
    P.pos.copy(G.spawn);
    camera.position.set(G.spawn.x + 28, G.spawn.y + 22, G.spawn.z + 28); camera.lookAt(G.spawn.x, G.spawn.y, G.spawn.z);
    G.ready = true;
    btn.disabled = false; btn.textContent = 'Play'; btn.onclick = startGame;
    window.addEventListener('keydown', (e) => { if (e.code === 'Enter' && (G.state === 'menu' || G.state === 'over')) startGame(); });
  } catch (err) {
    console.error(err); btn.textContent = 'Failed to load: ' + err.message;
  }
}
function spawnProp(kind='box') { const mat = new THREE.MeshStandardMaterial({ color: MODS.rainbow ? new THREE.Color().setHSL(Math.random(),.9,.6) : 0x56e7ff, metalness:.25, roughness:.3, emissive:0x123344 }); let mesh; if(kind==='sphere') mesh=new THREE.Mesh(new THREE.SphereGeometry(.8,20,14),mat); else if(kind==='cone') mesh=new THREE.Mesh(new THREE.ConeGeometry(.8,1.6,16),mat); else mesh=new THREE.Mesh(new THREE.BoxGeometry(1.4,1.4,1.4),mat); mesh.position.set(P.pos.x-Math.sin(P.yaw)*4,P.pos.y+2,P.pos.z-Math.cos(P.yaw)*4); scene.add(mesh); spawnedProps.push(mesh); return mesh; }
function setMod(name, value) { if (name in MODS) MODS[name]=!!value; }
window.__game = { G, P, CFG, stepGame, stepPlayer, startGame, keys, THREE, scene, camera, renderer, MODS, setMod, spawnProp, spawnedProps };
boot().then(() => renderer.setAnimationLoop(frame));
