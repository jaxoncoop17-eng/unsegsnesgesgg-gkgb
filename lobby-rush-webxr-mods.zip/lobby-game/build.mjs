// Build script: bundles src/main.js (+ vendored three.js / three-mesh-bvh / map.glb) into dist/
// Usage: npm install && npm run build
import { build } from 'esbuild';
import { copyFileSync, mkdirSync } from 'node:fs';

mkdirSync('dist', { recursive: true });
await build({
  entryPoints: ['src/main.js'],
  bundle: true,
  minify: true,
  format: 'iife',
  target: 'es2020',
  outfile: 'dist/game.js',
  alias: {
    three: './vendor/three-build/three.module.js',
    'three-addons': './vendor/three-addons',
    bvh: './vendor/bvh/index.js',
  },
  loader: { '.glb': 'binary' },
  logLevel: 'info',
});
copyFileSync('index.html', 'dist/index.html');
console.log('Built dist/index.html + dist/game.js');
