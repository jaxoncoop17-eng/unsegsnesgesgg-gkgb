# Lobby Rush — WebXR + Mods

Open `dist/index.html` in a browser for desktop mode. WebXR requires a compatible headset/browser and a secure origin (HTTPS or localhost); opening the file directly may not permit VR.

## Controls
- WASD: move; mouse: look
- Space: jump / double jump (and fly up with Fly mod)
- Shift: sprint; E: dash
- M: open/close mod menu
- Mod menu: Fly, Super speed, Low gravity, Rainbow lighting, spawn boxes/orbs/cones
- In VR: left thumbstick locomotion, primary button jump, secondary button dash (controller mappings vary by browser)

## Rebuild
`npm install && npm run build`
The build needs the `esbuild` npm package. `src/main.js` contains the source changes; `mods.js` is the runtime mod layer included in `dist/`.
